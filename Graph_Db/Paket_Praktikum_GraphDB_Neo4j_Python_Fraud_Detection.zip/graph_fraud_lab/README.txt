Graph-Based Fraud Detection Lab
================================

Isi:
- data/: dataset sintetis untuk latihan
- scripts/import_to_neo4j.py: membangun graph Neo4j dari CSV
- scripts/train_model.py: mengambil graph features dan melatih Random Forest
- docker-compose.yml: menjalankan Neo4j lokal
- requirements.txt: dependensi Python
- .env.example: contoh konfigurasi koneksi

Mulai dari panduan praktikum.md. Dataset sepenuhnya sintetis, bukan data nasabah nyata.
