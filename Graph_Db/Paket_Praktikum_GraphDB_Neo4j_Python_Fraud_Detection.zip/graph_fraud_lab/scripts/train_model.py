import os
from pathlib import Path
import pandas as pd
from neo4j import GraphDatabase
from dotenv import load_dotenv
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, average_precision_score, roc_auc_score
import joblib

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")
driver = GraphDatabase.driver(
    os.getenv("NEO4J_URI", "bolt://localhost:7687"),
    auth=(os.getenv("NEO4J_USERNAME", "neo4j"), os.getenv("NEO4J_PASSWORD", "GraphLab2026!"))
)
driver.verify_connectivity()

FEATURE_QUERY = """
MATCH (a:Account)
OPTIONAL MATCH (a)-[:USES]->(d:Device)<-[:USES]-(otherD:Account)
WHERE otherD <> a
WITH a, count(DISTINCT otherD) AS shared_device_accounts
OPTIONAL MATCH (a)-[:REGISTERED_AT]->(x:Address)<-[:REGISTERED_AT]-(otherA:Account)
WHERE otherA <> a
WITH a, shared_device_accounts, count(DISTINCT otherA) AS shared_address_accounts
OPTIONAL MATCH (a)-[:SENT]->(outTx:Transaction)
WITH a, shared_device_accounts, shared_address_accounts,
     count(outTx) AS outgoing_count, coalesce(sum(outTx.amount),0) AS outgoing_amount
OPTIONAL MATCH (inTx:Transaction)-[:RECEIVED_BY]->(a)
RETURN a.account_id AS account_id, a.is_fraud AS label,
       shared_device_accounts, shared_address_accounts,
       outgoing_count, outgoing_amount,
       count(inTx) AS incoming_count,
       coalesce(sum(inTx.amount),0) AS incoming_amount
ORDER BY account_id
"""

with driver.session(database=os.getenv("NEO4J_DATABASE", "neo4j")) as session:
    records = [r.data() for r in session.run(FEATURE_QUERY)]
driver.close()

df = pd.DataFrame(records)
features = ["shared_device_accounts", "shared_address_accounts",
            "outgoing_count", "outgoing_amount", "incoming_count", "incoming_amount"]
X = df[features].fillna(0)
y = df["label"].astype(int)

# Educational baseline: stratified random split. For a production project, use
# time-based split and construct features only from information available at scoring time.
X_train, X_test, y_train, y_test, id_train, id_test = train_test_split(
    X, y, df["account_id"], test_size=0.30, random_state=42, stratify=y
)
model = RandomForestClassifier(
    n_estimators=300, class_weight="balanced", random_state=42, max_depth=5
)
model.fit(X_train, y_train)
prob = model.predict_proba(X_test)[:, 1]
pred = (prob >= 0.50).astype(int)

print("=== Classification report ===")
print(classification_report(y_test, pred, zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print("PR-AUC / Average Precision:", round(average_precision_score(y_test, prob), 4))
if y_test.nunique() == 2:
    print("ROC-AUC:", round(roc_auc_score(y_test, prob), 4))

scored = pd.DataFrame({
    "account_id": id_test.values,
    "actual_label": y_test.values,
    "fraud_probability": prob,
    "predicted_alert": pred
}).sort_values("fraud_probability", ascending=False)
scored.to_csv(ROOT / "outputs_risk_scores.csv", index=False)
joblib.dump(model, ROOT / "fraud_random_forest.joblib")
print("\nTop risk scores:")
print(scored.head(10).to_string(index=False))
print("\nSaved outputs_risk_scores.csv and fraud_random_forest.joblib")
