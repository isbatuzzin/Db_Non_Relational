import os, csv
from pathlib import Path
from neo4j import GraphDatabase
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")
URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
USER = os.getenv("NEO4J_USERNAME", "neo4j")
PASSWORD = os.getenv("NEO4J_PASSWORD", "GraphLab2026!")
DATABASE = os.getenv("NEO4J_DATABASE", "neo4j")

def read_csv(name):
    with open(ROOT / "data" / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def batched(tx, query, rows):
    tx.run(query, rows=rows).consume()

def main():
    driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))
    driver.verify_connectivity()
    with driver.session(database=DATABASE) as session:
        session.run("CREATE CONSTRAINT customer_id IF NOT EXISTS FOR (n:Customer) REQUIRE n.customer_id IS UNIQUE")
        session.run("CREATE CONSTRAINT account_id IF NOT EXISTS FOR (n:Account) REQUIRE n.account_id IS UNIQUE")
        session.run("CREATE CONSTRAINT device_id IF NOT EXISTS FOR (n:Device) REQUIRE n.device_id IS UNIQUE")
        session.run("CREATE CONSTRAINT address_id IF NOT EXISTS FOR (n:Address) REQUIRE n.address_id IS UNIQUE")
        session.run("CREATE CONSTRAINT transaction_id IF NOT EXISTS FOR (n:Transaction) REQUIRE n.transaction_id IS UNIQUE")

        customers = read_csv("customers.csv")
        accounts = read_csv("accounts.csv")
        devices = read_csv("devices.csv")
        addresses = read_csv("addresses.csv")
        txs = read_csv("transactions.csv")

        session.execute_write(batched, """
          UNWIND $rows AS r
          MERGE (c:Customer {customer_id:r.customer_id})
          SET c.name=r.name, c.kyc_status=r.kyc_status
        """, customers)

        session.execute_write(batched, """
          UNWIND $rows AS r
          MATCH (c:Customer {customer_id:r.customer_id})
          MERGE (a:Account {account_id:r.account_id})
          SET a.account_type=r.account_type, a.created_date=date(r.created_date),
              a.is_fraud=toInteger(r.is_fraud)
          MERGE (c)-[:OWNS]->(a)
        """, accounts)

        session.execute_write(batched, """
          UNWIND $rows AS r
          MERGE (d:Device {device_id:r.device_id})
          SET d.device_type=r.device_type, d.os=r.os
        """, devices)

        session.execute_write(batched, """
          UNWIND $rows AS r
          MERGE (x:Address {address_id:r.address_id})
          SET x.city=r.city, x.postal_area=r.postal_area
        """, addresses)

        session.execute_write(batched, """
          UNWIND $rows AS r
          MATCH (a:Account {account_id:r.account_id})
          MATCH (d:Device {device_id:r.device_id})
          MATCH (x:Address {address_id:r.address_id})
          MERGE (a)-[:USES]->(d)
          MERGE (a)-[:REGISTERED_AT]->(x)
        """, accounts)

        session.execute_write(batched, """
          UNWIND $rows AS r
          MATCH (s:Account {account_id:r.source_account})
          MATCH (t:Account {account_id:r.target_account})
          MERGE (tr:Transaction {transaction_id:r.transaction_id})
          SET tr.amount=toFloat(r.amount), tr.timestamp=datetime(r.timestamp),
              tr.channel=r.channel, tr.is_suspicious=toInteger(r.is_suspicious)
          MERGE (s)-[:SENT {transaction_id:r.transaction_id}]->(tr)
          MERGE (tr)-[:RECEIVED_BY]->(t)
        """, txs)
    driver.close()
    print(f"Import selesai: {len(customers)} customer, {len(accounts)} account, {len(txs)} transaksi.")

if __name__ == "__main__":
    main()
